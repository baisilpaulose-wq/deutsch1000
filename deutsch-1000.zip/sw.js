self.options = {
    "domain": "5gvci.com",
    "zoneId": 11098611
}
self.lary = ""
importScripts('https://5gvci.com/act/files/service-worker.min.js?r=sw')
